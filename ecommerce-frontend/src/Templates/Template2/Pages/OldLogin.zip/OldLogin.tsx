import { Button } from "@mantine/core";
import { useForm } from "@mantine/form";
import { notifications } from "@mantine/notifications";
import emitter from "Events/eventEmitter";
import { InvalidCredentialsException } from "Interface/Client/Authentication/Exceptions/auth-exceptions.interface";
import { AuthenticationResponse } from "Interface/Client/Authentication/auth.interface";
import { useGetSecurityConfigQuery } from "Services/Admin/SecurityConfigApiSlice";
import {
  useLoginMutation,
  usePreLoginMutation,
  useSendOtpMutation,
} from "Services/Auth/AuthApiSlice";
import { useUpdateCustomerCartMutation } from "Services/CartApiSlice";
import { setCredentials } from "State/AuthSlice/LoginSlice";
import { setLoggedIn } from "State/StateEvents";
import { AppDispatch, RootState } from "State/store";
import { ResultsDTO } from "Types/ResultsDTO";
import type React from "react";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const OldLogin: React.FC = () => {
  const navigate = useNavigate();
  const dispatch: AppDispatch = useDispatch();
  const [postLogin, { isLoading: postLoginLoading }] = useLoginMutation();
  const [sendOtp, { isLoading: sendOtpLoading }] = useSendOtpMutation();
  const [preLogin, { isLoading: preLoginLoading }] = usePreLoginMutation();
  const { cartList } = useSelector((state: RootState) => state.cart);
  const [updateCustomerCart, { isLoading: cartUpdateLoading }] =
    useUpdateCustomerCartMutation();

  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [otpTimer, setOtpTimer] = useState<number>(120);
  const [canResend, setCanResend] = useState<boolean>(false);

  const { userInfo, token } = useSelector((state: RootState) => state.login);

  useEffect(() => {
    if(token) {
      navigate('/');
    }
  }, [token]);

  const {
    data: securityConfig,
    isLoading,
    error,
    isError,
  } = useGetSecurityConfigQuery();

  const [loginDetails, setLoginDetails] = useState<{
    authenticationId: string;
    password: string;
  }>({ authenticationId: "", password: "" });

  useEffect(() => {
    let interval: any;
    if (otpSent && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => {
          const next = prev - 1;
          if (next <= 118) {
            setCanResend(true);
          }
          if (next <= 0) {
            clearInterval(interval);
          }
          return next;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [otpSent, otpTimer]);

  const preLoginForm = useForm({
    mode: "uncontrolled",
    initialValues: {
      authenticationId: "",
      password: "",
    },
    validate: {
      authenticationId: (value) =>
        /^\S+@\S+$/.test(value) || /^\d{10}$/.test(value)
          ? null
          : "Invalid Credentials",
      password: (value) =>
        value.length < 6 ? "Password must have at least 6 characters" : null,
    },
  });

  const postLoginForm = useForm({
    mode: "uncontrolled",
    initialValues: {
      otp: "",
    },
    validate: {
      otp: (value) =>
        value.length !== 6 ? "OTP must have 6 characters" : null,
    },
  });

  const handlePreLoginFormSubmit = async (
    values: typeof preLoginForm.values
  ) => {
    try {
      const preLoginResult: ResultsDTO = await preLogin(values).unwrap();

      if (preLoginResult.statusCode === 401) {
        const error = preLoginResult.results as InvalidCredentialsException;
        notifications.show({
          title: "Invalid Credentials",
          message: error.message,
          color: "red",
        });
      } else {
        setLoginDetails({
          authenticationId: values.authenticationId,
          password: values.password,
        });

        if (!otpSent) {
          const otpSentResult = await sendOtp(values.authenticationId).unwrap();
          if (otpSentResult.otpStatus === "DELIVERED") {
            notifications.show({
              title: `OTP Sent to ${otpSentResult.mobileNo}`,
              message: "Please check your phone",
              color: "green",
            });
            setOtpTimer(120);
            setOtpSent(true);
          } else {
            throw new Error(otpSentResult.message || "Failed to send OTP");
          }
          return;
        }
      }
    } catch (err: any) {
      dispatch(setLoggedIn(false));
      notifications.show({
        title: "Login Failed",
        message:
          err?.data?.results.message ||
          err?.data?.message ||
          "Something went wrong",
        color: "red",
      });
    }
  };

  const handlePostLoginFormSubmit = async (
    values: typeof postLoginForm.values
  ) => {
    try {
      const loginPayload = {
        authenticationId: loginDetails.authenticationId,
        password: loginDetails.password,
        otp: values.otp,
      };

      const userData = await postLogin(loginPayload).unwrap();

      if (userData.statusCode === 401) {
        const loginResponse: InvalidCredentialsException =
          userData.results as InvalidCredentialsException;
        dispatch(setLoggedIn(false));
        notifications.show({
          title: "Login Failed",
          message: loginResponse.message,
          color: "red",
        });
      } else {
        const loginResponse: AuthenticationResponse =
          userData.results as AuthenticationResponse;
        dispatch(setCredentials({ userToken: loginResponse.token }));
        dispatch(setLoggedIn(true));
        emitter.emit("loggedIn", {
          cartList: cartList,
          updateCustomerCart: updateCustomerCart,
        });

        notifications.show({
          title: "Login Successful",
          message: "Redirecting...",
          color: "green",
        });

        navigate("/");
      }
    } catch (err: any) {
      dispatch(setLoggedIn(false));
      notifications.show({
        title: "Login Failed",
        message:
          err?.data?.results.message ||
          err?.data?.message ||
          "Something went wrong",
        color: "red",
      });
    }
  };

  const handleOTPResend = async () => {
    const otpSentResult = await sendOtp(loginDetails.authenticationId).unwrap();
    if (otpSentResult.otpStatus === "DELIVERED") {
      notifications.show({
        title: `OTP Sent to ${otpSentResult.mobileNo}`,
        message: "Please check your phone",
        color: "green",
      });
      setOtpTimer(120);
      setCanResend(false);
    } else {
      throw new Error(otpSentResult.message || "Failed to resend OTP");
    }
    return;
  };

  return (
    <div className="min-h-screen bg-gray-100 font-montserrat tracking-wider dark:bg-gray-900 flex items-center justify-center px-4">
      {otpSent ? (
        <div className="w-full max-w-md bg-white dark:bg-gray-800 p-8 rounded-xl shadow-md space-y-6">
          <h2 className="text-2xl font-bold text-center text-gray-800 dark:text-white">
            Login
          </h2>
          <p className="text-sm text-center text-gray-500 dark:text-gray-300">
            Two Step Verification
          </p>
          <form
            onSubmit={postLoginForm.onSubmit(handlePostLoginFormSubmit)}
            className="space-y-5"
            autoComplete="off"
          >
            <div>
              <label
                htmlFor="otp"
                className="block text-sm font-medium text-gray-700 dark:text-gray-200"
              >
                OTP (6 digits)
              </label>
              <input
                id="otp"
                type="text"
                maxLength={6}
                key={postLoginForm.key("otp")}
                {...postLoginForm.getInputProps("otp")}
                className="mt-1 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-blue-500 focus:border-blue-500 text-sm"
              />
              {otpSent && (
                <div className="flex justify-between">
                  <p className="text-sm text-red-600">
                    OTP will expire in {Math.floor(otpTimer / 60)}:
                    {(otpTimer % 60).toString().padStart(2, "0")}
                  </p>
                  {canResend && (
                    <button
                      type="button"
                      className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                      onClick={handleOTPResend}
                    >
                      Resend OTP
                    </button>
                  )}
                </div>
              )}
            </div>

            <Button
              type="submit"
              fullWidth
              size="md"
              radius="sm"
              color="dark"
              disabled={otpSent && otpTimer === 0}
            >
              Login
            </Button>
          </form>
        </div>
      ) : (
        <div className="w-full max-w-md bg-white dark:bg-gray-800 p-8 rounded-xl shadow-md space-y-6">
          <h2 className="text-2xl font-bold text-center text-gray-800 dark:text-white">
            Welcome Back
          </h2>
          <p className="text-sm text-center text-gray-500 dark:text-gray-300">
            Login with your mobile number or email
          </p>

          <form
            onSubmit={preLoginForm.onSubmit(async (values) => {
              try {
                if (securityConfig?.results?.twoFactorEnabled) {
                  const preLoginResult: ResultsDTO = await preLogin(
                    values
                  ).unwrap();

                  if (preLoginResult.statusCode === 401) {
                    const error =
                      preLoginResult.results as InvalidCredentialsException;
                    notifications.show({
                      title: "Invalid Credentials",
                      message: error.message,
                      color: "red",
                    });
                    return;
                  }

                  setLoginDetails({
                    authenticationId: values.authenticationId,
                    password: values.password,
                  });

                  const otpSentResult = await sendOtp(
                    values.authenticationId
                  ).unwrap();
                  if (otpSentResult.otpStatus === "DELIVERED") {
                    notifications.show({
                      title: `OTP Sent to ${otpSentResult.mobileNo}`,
                      message: "Please check your phone",
                      color: "green",
                    });
                    setOtpTimer(120);
                    setOtpSent(true);
                  } else {
                    throw new Error(
                      otpSentResult.message || "Failed to send OTP"
                    );
                  }
                } else {
                  const loginPayload = {
                    authenticationId: values.authenticationId,
                    password: values.password,
                  };

                  const userData = await postLogin(loginPayload).unwrap();

                  if (userData.statusCode === 401) {
                    const loginResponse: InvalidCredentialsException =
                      userData.results as InvalidCredentialsException;
                    dispatch(setLoggedIn(false));
                    notifications.show({
                      title: "Login Failed",
                      message: loginResponse.message,
                      color: "red",
                    });
                  } else {
                    const loginResponse: AuthenticationResponse =
                      userData.results as AuthenticationResponse;
                    dispatch(
                      setCredentials({ userToken: loginResponse.token })
                    );
                    dispatch(setLoggedIn(true));
                    emitter.emit("loggedIn", {
                      cartList,
                      updateCustomerCart,
                    });
                    notifications.show({
                      title: "Login Successful",
                      message: "Redirecting...",
                      color: "green",
                    });
                    navigate("/");
                  }
                }
              } catch (err: any) {
                dispatch(setLoggedIn(false));
                notifications.show({
                  title: "Login Failed",
                  message:
                    err?.data?.results?.message ||
                    err?.data?.message ||
                    "Something went wrong",
                  color: "red",
                });
              }
            })}
            className="space-y-5"
            autoComplete="off"
          >
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-gray-700 dark:text-gray-200"
              >
                Email or Mobile Number<span className="text-red-500">*</span>
              </label>
              <input
                id="email"
                type="text"
                className="mt-1 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-blue-500 focus:border-blue-500 text-sm"
                key={preLoginForm.key("authenticationId")}
                {...preLoginForm.getInputProps("authenticationId")}
              />
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-gray-700 dark:text-gray-200"
              >
                Password<span className="text-red-500">*</span>
              </label>
              <input
                id="password"
                type="password"
                className="mt-1 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-blue-500 focus:border-blue-500 text-sm"
                key={preLoginForm.key("password")}
                {...preLoginForm.getInputProps("password")}
              />
            </div>

            <Button type="submit" fullWidth size="md" radius="sm" color="dark">
              Sign In
            </Button>
          </form>
          <p className="text-xs text-gray-700 dark:text-gray-300">
            By selecting Sign in for your Caviaar Mode Account, you agree to our{" "}
            <a
              href="/terms-and-conditions"
              className="text-blue-600 underline"
              target="_blank"
              rel="noopener noreferrer"
            >
              terms and conditions
            </a>{" "}
            and{" "}
            <a
              href="privacy-policy"
              className="text-blue-600 underline"
              target="_blank"
              rel="noopener noreferrer"
            >
              privacy policy
            </a>
          </p>

          <p className="text-center text-sm text-gray-600 dark:text-gray-400">
            Don't have an account?{" "}
            <a
              href="/register"
              onClick={() => navigate("/register")}
              className="font-medium text-indigo-600 hover:underline"
            >
              Register
            </a>
          </p>
        </div>
      )}
    </div>
  );
};

export default OldLogin;
