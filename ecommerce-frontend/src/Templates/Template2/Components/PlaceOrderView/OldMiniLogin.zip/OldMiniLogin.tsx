import { Button, PasswordInput, Stack, Text, TextInput, Title } from "@mantine/core";
import { useForm } from "@mantine/form";
import { notifications } from "@mantine/notifications";
import emitter from "Events/eventEmitter";
import { InvalidCredentialsException } from "Interface/Client/Authentication/Exceptions/auth-exceptions.interface";
import { AuthenticationResponse } from "Interface/Client/Authentication/auth.interface";
import { useGetSecurityConfigQuery } from "Services/Admin/SecurityConfigApiSlice";
import { useLoginMutation, usePreLoginMutation, useSendOtpMutation } from "Services/Auth/AuthApiSlice";
import { useUpdateCustomerCartMutation } from "Services/CartApiSlice";
import { setCredentials } from "State/AuthSlice/LoginSlice";
import { setLoggedIn } from "State/StateEvents";
import { AppDispatch, RootState } from "State/store";
import { ResultsDTO } from "Types/ResultsDTO";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

type Props = {
    next: () => void
}

const MiniLoginTab = ({next}: Props) => {
    const [postLogin, { isLoading: postLoginLoading }] = useLoginMutation();
    const { cartList } = useSelector((state: RootState) => state.cart);
    const dispatch: AppDispatch = useDispatch();
    const [updateCustomerCart, { isLoading: cartUpdateLoading }] = useUpdateCustomerCartMutation();
    const [sendOtp, { isLoading: sendOtpLoading }] = useSendOtpMutation();
    const [preLogin, { isLoading: preLoginLoading }] = usePreLoginMutation();
    const [otpSent, setOtpSent] = useState<boolean>(false);
    const [otpTimer, setOtpTimer] = useState<number>(120);
    const [canResend, setCanResend] = useState<boolean>(false);
    const [loginDetails, setLoginDetails] = useState<{ authenticationId: string, password: string }>({ authenticationId: "", password: "" });
    const { data: securityConfig, isLoading, error, isError } = useGetSecurityConfigQuery();
      useEffect(() => {
        let interval: any;
        if (otpSent && otpTimer > 0) {
          interval = setInterval(() => {
            setOtpTimer((prev) => {
              const next = prev - 1;
              if (next <= 118) {
                setCanResend(true);
              }
              if (next <= 0) {
                clearInterval(interval);
              }
              return next;
            });
          }, 1000);
        }
    
        return () => clearInterval(interval);
      }, [otpSent, otpTimer]);

    const preLoginForm = useForm({
        mode: 'uncontrolled',
        initialValues: {
            authenticationId: '',
            password: ''
        },
        validate: {
            authenticationId: (value) => /^\S+@\S+$/.test(value) || /^\d{10}$/.test(value) ? null : "Invalid Credentials",
            password: (value) => value.length < 5 ? "Password must have at least 5 characters" : null,
        }
    })

    const postLoginForm = useForm({
    mode: "uncontrolled",
    initialValues: {
        otp: ""
    },
    validate: {
        otp: (value) => value.length !== 6 ? "OTP must have 6 characters" : null
    },
    })

    
    const handlePreLoginFormSubmit = async (values: typeof preLoginForm.values) => {
    try {

        const preLoginResult: ResultsDTO = await preLogin(values).unwrap();

        if(preLoginResult.statusCode === 401) {
        const error = preLoginResult.results as InvalidCredentialsException;
        notifications.show({
            title: "Invalid Credentials",
            message: error.message,
            color: "red",
        });
        } else {
        setLoginDetails({ authenticationId: values.authenticationId, password: values.password });

        if (!otpSent) {
            const otpSentResult = await sendOtp(values.authenticationId).unwrap();
            if (otpSentResult.otpStatus === "DELIVERED") {
            notifications.show({
                title: `OTP Sent to ${otpSentResult.mobileNo}`,
                message: "Please check your phone",
                color: "green",
            });
            setOtpTimer(120);
            setOtpSent(true);
            
            } else {
            throw new Error(otpSentResult.message || "Failed to send OTP");
            }
            return;
        }
        }

    } catch (err: any) {
        dispatch(setLoggedIn(false));
        notifications.show({
        title: "Login Failed",
        message: err?.data?.results.message || err?.data?.message || "Something went wrong",
        color: "red",
        });
    }
    };

    const handlePostLoginFormSubmit = async (values: typeof postLoginForm.values) => {
        try {
            

            const loginPayload = {
                authenticationId: loginDetails.authenticationId,
                password: loginDetails.password,
                otp: values.otp,
            };

            const userData = await postLogin(loginPayload).unwrap();

            if(userData.statusCode === 401) {
                const loginResponse: InvalidCredentialsException = userData.results as InvalidCredentialsException;
                dispatch(setLoggedIn(false));
                notifications.show({
                    title: "Login Failed",
                    message: loginResponse.message,
                    color: "red",
                });
            } else {
            const loginResponse: AuthenticationResponse = userData.results as AuthenticationResponse;
            dispatch(setCredentials({ userToken: loginResponse.token }));
            dispatch(setLoggedIn(true));
            emitter.emit("loggedIn", {
                cartList: cartList,
                updateCustomerCart: updateCustomerCart,
            });
    
            notifications.show({
                title: "Login Successful",
                message: "Redirecting...",
                color: "green",
            });
    
            next();
            }

            
        } catch(err: any) {
            dispatch(setLoggedIn(false));
            notifications.show({
                title: "Login Failed",
                message: err?.data?.results.message || err?.data?.message || "Something went wrong",
                color: "red",
            });
        }
    }

    const handleOTPResend = async () => {
    const otpSentResult = await sendOtp(loginDetails.authenticationId).unwrap();
    if (otpSentResult.otpStatus === "DELIVERED") {
        notifications.show({
        title: `OTP Sent to ${otpSentResult.mobileNo}`,
        message: "Please check your phone",
        color: "green",
        });
        setOtpTimer(120);
        setCanResend(false);
    } else {
        throw new Error(otpSentResult.message || "Failed to resend OTP");
    }
    return;
    }

    return (
        <div style={{ width: '100%' }}>
            {otpSent ? (
                <div>
                    <form onSubmit={postLoginForm.onSubmit(handlePostLoginFormSubmit)} style={{ width: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                        <Title ta={'center'} c="var(--mantine-color-dimmed)" order={4}>Two Factor Verification</Title>
                        <Stack gap={10}>
                            <TextInput
                                size="md"
                                radius={0}
                                py={10}
                                maxLength={6}
                                placeholder='6 - Digit OTP'
                                key={postLoginForm.key("otp")}
                                {...postLoginForm.getInputProps("otp")}
                            />
                            {otpSent && (
                                <div className="flex justify-between space-x-2">
                                    <p className="text-sm text-red-600">OTP will expire in {Math.floor(otpTimer / 60)}:{(otpTimer % 60).toString().padStart(2, '0')}</p>
                                    {
                                        canResend && (
                                            <button
                                                type="button"
                                                className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                                                onClick={handleOTPResend}
                                            >
                                                Resend OTP
                                            </button>
                                        )
                                    }
                                </div>

                            )}
                            <Button
                                type="submit"
                                fullWidth
                                size="md"
                                radius="sm"
                                color="dark"
                                disabled={otpSent && otpTimer === 0}
                            >
                                Login
                            </Button>
                        </Stack>
                    </form>
                </div>
            ) : (
                <div>
                        <form onSubmit={preLoginForm.onSubmit(async (values) => {
                            try {
                                if (securityConfig?.results?.twoFactorEnabled) {
                                    const preLoginResult: ResultsDTO = await preLogin(values).unwrap();

                                    if (preLoginResult.statusCode === 401) {
                                        const error = preLoginResult.results as InvalidCredentialsException;
                                        notifications.show({
                                            title: "Invalid Credentials",
                                            message: error.message,
                                            color: "red",
                                        });
                                        return;
                                    }

                                    setLoginDetails({
                                        authenticationId: values.authenticationId,
                                        password: values.password,
                                    });

                                    const otpSentResult = await sendOtp(values.authenticationId).unwrap();
                                    if (otpSentResult.otpStatus === "DELIVERED") {
                                        notifications.show({
                                            title: `OTP Sent to ${otpSentResult.mobileNo}`,
                                            message: "Please check your phone",
                                            color: "green",
                                        });
                                        setOtpTimer(120);
                                        setOtpSent(true);
                                    } else {
                                        throw new Error(otpSentResult.message || "Failed to send OTP");
                                    }

                                } else {
                                    const loginPayload = {
                                        authenticationId: values.authenticationId,
                                        password: values.password,
                                    };

                                    const userData = await postLogin(loginPayload).unwrap();

                                    if (userData.statusCode === 401) {
                                        const loginResponse: InvalidCredentialsException = userData.results as InvalidCredentialsException;
                                        dispatch(setLoggedIn(false));
                                        notifications.show({
                                            title: "Login Failed",
                                            message: loginResponse.message,
                                            color: "red",
                                        });
                                    } else {
                                        const loginResponse: AuthenticationResponse = userData.results as AuthenticationResponse;
                                        dispatch(setCredentials({ userToken: loginResponse.token }));
                                        dispatch(setLoggedIn(true));
                                        emitter.emit("loggedIn", {
                                            cartList,
                                            updateCustomerCart,
                                        });
                                        notifications.show({
                                            title: "Login Successful",
                                            message: "Redirecting...",
                                            color: "green",
                                        });
                                        next();
                                    }
                                }
                            } catch (err: any) {
                                dispatch(setLoggedIn(false));
                                notifications.show({
                                    title: "Login Failed",
                                    message: err?.data?.results?.message || err?.data?.message || "Something went wrong",
                                    color: "red",
                                });
                            }
                        })} style={{ width: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                            <Title ta={'center'} c="var(--mantine-color-dimmed)" order={4}>Login</Title>
                            <Stack gap={10}>
                                <TextInput
                                    size="md"
                                    radius={0}
                                    py={10}
                                    placeholder='Email Address or Mobile Number'
                                    required
                                    key={preLoginForm.key('authenticationId')}
                                    {...preLoginForm.getInputProps('authenticationId')}
                                />
                                <PasswordInput
                                    size="md"
                                    radius={0}
                                    py={10}
                                    placeholder='Password'
                                    required
                                    key={preLoginForm.key('password')}
                                    {...preLoginForm.getInputProps('password')}
                                />

                                <Text ta={'center'}>By continuing, I agree to the terms of use & privacy policy.</Text>

                                <button
                                    type="submit"
                                    className="uppercase tracking-widest bg-black text-white border border-black text-xs font-semibold px-8 py-4 transition-all duration-300 ease-in-out hover:bg-transparent hover:text-black relative overflow-hidden group"

                                >Continue
                                </button>

                            </Stack>
                        </form>
                </div>
            )}
            
        </div>
    );
}

export default MiniLoginTab;